-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2024 at 02:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `owner` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartid`, `userid`, `pid`, `owner`, `created_date`) VALUES
(101, 3, 26, 1, '2024-11-18 13:27:31'),
(102, 3, 25, 1, '2024-11-18 13:27:38'),
(103, 3, 25, 1, '2024-11-18 13:27:39');

-- --------------------------------------------------------

--
-- Table structure for table `myorders`
--

CREATE TABLE `myorders` (
  `orderid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `order_created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `myorders`
--

INSERT INTO `myorders` (`orderid`, `userid`, `pid`, `owner`, `order_created_date`) VALUES
(38, 8, 23, 1, '2024-11-18 13:09:47'),
(39, 8, 25, 1, '2024-11-18 13:09:47'),
(40, 8, 26, 1, '2024-11-18 13:09:47'),
(41, 3, 23, 1, '2024-11-18 13:21:23'),
(42, 3, 23, 1, '2024-11-18 13:21:23'),
(43, 3, 23, 1, '2024-11-18 13:21:23'),
(44, 3, 23, 1, '2024-11-18 13:21:23'),
(45, 3, 23, 1, '2024-11-18 13:21:23'),
(46, 3, 23, 1, '2024-11-18 13:21:23'),
(47, 3, 23, 1, '2024-11-18 13:21:23');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `details` text NOT NULL,
  `impath` varchar(500) NOT NULL,
  `owner` int(10) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `name`, `price`, `details`, `impath`, `owner`, `created_date`) VALUES
(23, 'Levis', 999, 'Levis Mens Regular Fit Batwing Brand Logo T-Shirt', '../shared/images/shirt1.jpg', 1, '2024-11-18 12:53:05'),
(25, 'Adidas', 1299, 'Adidas Mens Striped Regular Fit T-Shirt.......', '../shared/images/adidas.jpg', 1, '2024-11-18 12:59:30'),
(26, 'Superman', 899, 'The Souled Store Superman: Iconic Emblem Mens......', '../shared/images/superman.jpg', 1, '2024-11-18 13:04:17'),
(27, 'Batman', 1599, 'The Souled Store Men Official Batman.........', '../shared/images/batmaN.jpg', 1, '2024-11-18 13:03:45'),
(28, 'Allen Solly', 799, 'Allen Solly Mens Solid Regular Fit Polo.......', '../shared/images/allen.jpg', 1, '2024-11-18 13:06:24'),
(29, 'US Polo', 999, 'U.S. POLO ASSN. Mens Regular Fit T-Shirt...', '../shared/images/us.jpg', 1, '2024-11-18 13:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(15) NOT NULL,
  `address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `usertype`, `address`) VALUES
(1, 'Shekhar', 'Shekhar', 'Seller', 'Pune'),
(2, 'Rhushi', 'Rhushi', 'Buyer', 'Mumbai'),
(3, 'Sk', 'Sk', 'Buyer', 'Nashik'),
(4, 'RG', 'Rg', 'Buyer', 'Nagpur'),
(6, 'SSk', 'SSk', 'Seller', 'Nagpur'),
(7, 'Shekhar', '123456', 'Buyer', 'pune'),
(8, 'Shekhar', 'pune123', 'Buyer', 'pune');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartid`);

--
-- Indexes for table `myorders`
--
ALTER TABLE `myorders`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `myorders`
--
ALTER TABLE `myorders`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
