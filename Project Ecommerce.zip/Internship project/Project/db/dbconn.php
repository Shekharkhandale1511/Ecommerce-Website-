<?php
	$conn=new mysqli("localhost","root","","project",3306);
	if(!$conn){
		die("Fatal Error: Connection Error!");
	}

?>
