<?php
    header("Location:shared/login.html");
?>