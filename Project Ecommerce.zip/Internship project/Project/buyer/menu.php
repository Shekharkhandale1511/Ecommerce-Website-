<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../css/menu.css">

</head>

<title>
    Online Tshirt Store
</title>

<body>
    <?php
    include "../design/header.php"
    ?> 
    <br>
    <div class="container" >
       <div class="nav">
       <ul>
        
        <li class="nav">
            <a href="home.php">View Product</a>
        </li>
        <li>|</li>
            <li>
            <a href="viewcart.php">View Cart</a>
            </li>
            <li>|</li>
            <li>
                <a href="trackorders.php">Track Orders</a>
            </li>
        </ul>
       </div>
    </div>
</body>
</html>